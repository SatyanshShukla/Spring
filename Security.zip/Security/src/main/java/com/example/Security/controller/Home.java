package com.example.Security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.Security.model.JwtRequest;
import com.example.Security.model.JwtResponse;
import com.example.Security.service.CustomUserDetailsService;
import com.example.Security.utility.Util;

@RestController
public class Home {
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;
	
	@Autowired
	private Util util;
	
	@GetMapping("/get")
	public String home(){
		return "Homepage";
	}
	@RequestMapping(value = "/token", method = RequestMethod.POST)
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception{
		System.out.println(jwtRequest);
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(),jwtRequest.getPassword()));
		}
		catch(UsernameNotFoundException e){
			e.printStackTrace();
			throw new Exception("BAD Credentials");
		}
		catch(BadCredentialsException e) {
			e.printStackTrace();
			throw new Exception("Bad credentials");
		}
		
		UserDetails username = this.customUserDetailsService.loadUserByUsername(jwtRequest.getUsername());
		String token = this.util.generateToken(username);
		System.out.println(token+ " : Token");
		
		return ResponseEntity.ok(new JwtResponse(token));
	}

}
